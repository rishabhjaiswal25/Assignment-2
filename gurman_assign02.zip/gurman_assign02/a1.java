package gurman_assign02;
import java.util.Scanner;

public class a1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		int letter=64;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of rows");
		int rows=sc.nextInt();
		for(i=1; i<=rows; i++){
		  for(j=1; j<=i; j++){
		  System.out.print((char)(j+letter));
		}
		System.out.println();

	}

}
}