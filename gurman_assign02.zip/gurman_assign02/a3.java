package gurman_assign02;

import java.util.Scanner;

public class a3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size :");
        n = sc.nextInt();
		for (int p=2;p<n+2;p++) {
			for(int q=2;q<=p;q++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		
        sc.close();

	}

}
