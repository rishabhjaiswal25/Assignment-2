package gurman_assign02;

import java.util.Scanner;

public class a5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of elements you want to enter ");
		int n=sc.nextInt();
		int[] a=new int[n];
		System.out.println("Enter the "+n+" elements ");
		for (int i=0;i<n;i++) {
			a[i]=sc.nextInt();
		}
		int max=a[0];
		for (int i=1;i<n;i++) {
			if(a[i]>max) {
				max=a[i];
			}
		}
		System.out.println("Maximum number is: "+max);
       sc.close();

	}

}
