package gurman_assign02;

import java.util.Scanner;

public class a2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size of Number triangle :");
        n = sc.nextInt();
		for (int p=1;p<n+1;p++) {
			for(int q=1;q<=p;q++) {
				System.out.print(" "+q);
			}
			System.out.println("");
		}
		sc.close();
	}

}
